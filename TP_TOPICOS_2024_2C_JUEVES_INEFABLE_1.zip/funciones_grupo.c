/*
    Integrantes del grupo. En caso de ser un grupo de dos integrantes, no completar el último campo.
    Si alguno de los integrantes del grupo dejara la materia, completar de todos modos sus datos, aclarando que no entrega.
    -----------------
    Apellido: Bernardo
    Nombre: Ivan Ezequiel
    DNI: 45219693
    Entrega: Si
    -----------------
    Apellido: Perez
    Nombre: Olivia Constanza
    DNI: 46641730
    Entrega: Si
    -----------------
    Apellido: Candado Cabanas
    Nombre: Cristhian Daniel
    DNI: 94442368
    Entrega: No
    CRISTHIAN CANDADO NO ENTREGA, PERO PARA EVITAR LOS MOVIMIENTOS CIRCULARES DE LOS ARCHIVOS,
    ESCRIBIMOS TODOS LOS PROTOTIPOS DE LAS FUNCIONES EN SU HEADER
    -----------------
*/
#include "funciones_grupo.h"

int solucion(int argc, char* argv[])
{
    /*
        Aquí deben hacer el código que solucione lo solicitado.
        Todas las funciones utilizadas deben estar declaradas en este archivo, y en su respectivo .h
    */

    return funcionPrincipal(argc,argv);
}
