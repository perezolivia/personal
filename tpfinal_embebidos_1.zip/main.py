import time
import machine
import micropython
import network
from lcd_i2c import LCD
from machine import I2C, Pin
from machine import Pin,PWM
from umqtt.simple import MQTTClient

#Indicamos red WIFI y clave

ssid = 'Wokwi-GUEST'
wifipassword = ''

#Datos server MQTT (broker)
#Indico datos MQTT Broker (server y puerto)

mqtt_server = 'io.adafruit.com'
port = 1883
user = 'Luuuulu' 
password = 'aio_FpCg49oVE4dMLFfSKNdqNu430f0A' #regenerar clave
client_id = 'Alarma'
topic_PIR = 'Luuuulu/feeds/SensorPIR'
topic_ALARMA = 'Luuuulu/feeds/Alarma'

I2C_ADDR = 0x27     # DEC 39, HEX 0x27
i2c = I2C(0, scl=Pin(18), sda=Pin(19), freq=800000)
lcd = LCD(addr=I2C_ADDR, cols=20, rows=4, i2c=i2c)

lcd.begin()



#Alarma activa si o no

ALARMA_ACTIVA = False
LEDESTADO = Pin(17, Pin.OUT) #led de estado (ALARMA)

#definimos notas para la cancion de la alarma
do = 523
re = 587
mi = 659
fa = 698
sol = 783
la = 880
si = 987
do_alto = 1046
re_alto = 1175
pause = 1



sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)

#Conectamos a WIFI

sta_if.connect(ssid,wifipassword)
lcd.print("Conectando")
time.sleep(2)
lcd.clear()
while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.1)

lcd.print("Conectado a WIFI")

time.sleep(2)
lcd.clear()


#vemos cuales son las ip

print(sta_if.ifconfig())

def callback_alarma(topic, msg):
    global ALARMA_ACTIVA,LEDESTADO
    dato = msg.decode('utf-8')
    topicrec = topic.decode('utf-8')
    print("Mensaje en tópico "+topicrec+":"+dato)

    if topicrec == topic_ALARMA and "OFF" in dato:
        ALARMA_ACTIVA=False
        lcd.print("ALARMA APAGADA")
        time.sleep(2)
        lcd.clear()
    else:
        ALARMA_ACTIVA = True
        LEDESTADO.value(ALARMA_ACTIVA)
        lcd.print("ALARMA ENCENDIDA")
        time.sleep(2)
        lcd.clear()


#Intentamos conectarnos al broker MQTT


try:
    conexionMQTT = MQTTClient(client_id, mqtt_server,user=user,password=password,port=int(port))
    conexionMQTT.set_callback(callback_alarma) #Funcion Callback para recibir del broker mensajes
    conexionMQTT.connect() #Hacemos la conexión.
    conexionMQTT.subscribe(topic_ALARMA) #Nos suscribimos a un tópico luego del connect
    
    lcd.print("\nConectado con Broker MQTT")
    time.sleep(2)
    lcd.clear()
except OSError as e:

    #Si falló la conexión, reiniciamos todo

   

    lcd.print("Fallo la conexion al Broker, reiniciando...")
    time.sleep(2)
    lcd.clear()
    time.sleep(5)
    machine.reset()

#Armamos un loop infinito que chequea por mensajes nuevos
#y verifica el estado del PIR

sensorPIR = Pin(13, Pin.IN) #define el sensor PIR
LEDPIR= Pin(12,Pin.OUT) #define el led de estado del PIR
SIRENA = PWM(Pin(5), freq=1200, duty_u16=32768) #define el parlante (la sirena)
SIRENA.duty(0)
estado_PIR = sensorPIR.value()
lcd.print("Comenzando monitoreo del sensor PIR")
time.sleep(2)
SUENA_ALARMA=False #estado sirena (aun no suena)
lcd.clear()


def sonido(freq, duracion):

    if SUENA_ALARMA:
        print ("No debiste desconfiar de Rick.") #mensaje MUY amenazante
        LEDESTADO.value(1)
        SIRENA.freq(freq)
        SIRENA.duty(512)
        time.sleep_ms(duracion)
        SIRENA.duty(0)
        LEDESTADO.value(0)
        time.sleep_ms(50)

melodia = [
    do, re, fa, re, la, pause, la, sol, pause,
    pause, do, re, fa, re, sol, sol, pause, fa, pause,
    pause, do, re, fa, re, fa, pause, sol, mi, re, do, pause,
    do, sol, pause, fa, pause, pause,
    pause, do, re, fa, re, la, pause, la, sol, pause,
    pause, do, re, fa, re, do_alto, pause, mi, fa, mi, re, pause,
    do, re, fa, re, fa, pause, sol, mi, re, do, pause,
    do, sol, pause, fa
]  # melodia totalmente inofensiva y agradable

len_nota = [200] * len(melodia)



while True:

    #Si se produce una excepción, por ejemplo se corta el wifi
    #o perdemos la conexión MQTT, simplemente vamos a reiniciar
    #el micro para que comience la secuencia nuevamente, así que
    #usamos un bloque Try+Except

    try:

        #Tenemos que verificar si hay mensajes nuevos publicados por el broker

        conexionMQTT.check_msg()
        time.sleep_ms(2000)

        #actualizamos el LED

        estado_PIRNuevo = sensorPIR.value()
        LEDPIR.value(estado_PIRNuevo)

        #Si la alarma esta encendida
        if ALARMA_ACTIVA:
           
            
            
            #Y el PIR detecta movimiento
            if estado_PIRNuevo:
                #Entonces hace sonar la alarma
                SUENA_ALARMA=True
                
                
               

                #Si el estado anterior del PIR = 0 notificamos
                #ya que el PIR estaba apagado y ahora encendido
                #detectar movimiento
                if not estado_PIR:
                    #enviamos al server el cambio

                    lcd.print("MOVIMIENTO DETECTADO. ALARMA SONANDO.")
                    time.sleep(2)
                    lcd.clear()

                    
                    
                    conexionMQTT.publish(topic_PIR,str(1))
                    
            else:
                #Si PIR no detecta movimiento pero lo hizo antes notificamos
                if estado_PIR:
                    
                    conexionMQTT.publish(topic_PIR,str(1))
                    
        else:
            #Si la alarma no esta activa NO debe sonar
            SUENA_ALARMA=False
            conexionMQTT.publish(topic_PIR,str(0))

        #Siempre actualizamos el estado del PIR
        estado_PIR = estado_PIRNuevo
        if SUENA_ALARMA:
            for nota, duracion in zip(melodia, len_nota):
                sonido(nota, duracion) #reproduce la cancion
           
        else:
            SIRENA.duty(0) #no suena
           
    except OSError as e:
        print("Error ",e)
        time.sleep(5)
        machine.reset() #resetea


